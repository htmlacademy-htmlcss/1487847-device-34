function openForm() {
  document.querySelector('.modal-container').classList.add('open-form');
}
function closeForm() {
  document.querySelector('.modal-container').classList.remove('open-form');
}
